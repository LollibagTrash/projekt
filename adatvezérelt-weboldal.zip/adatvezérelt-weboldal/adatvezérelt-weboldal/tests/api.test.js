const test = require("node:test");
const assert = require("node:assert/strict");
const { server } = require("../server");

let baseUrl;
let createdId;

 test.before(async () => {
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
});

test("GET /api/shoes terméklistát ad vissza", async () => {
  const response = await fetch(`${baseUrl}/api/shoes`);
  const shoes = await response.json();
  assert.equal(response.status, 200);
  assert.ok(Array.isArray(shoes));
  assert.ok(shoes.length >= 1);
});

test("POST /api/shoes új terméket hoz létre", async () => {
  const response = await fetch(`${baseUrl}/api/shoes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Teszt Runner",
      brand: "StrideLab",
      category: "Futócipő",
      gender: "Unisex",
      description: "Automatikus teszttermék.",
      price: 19990,
      oldPrice: null,
      image: "https://example.com/test.jpg"
    })
  });
  const shoe = await response.json();
  createdId = shoe.id;
  assert.equal(response.status, 201);
  assert.equal(shoe.name, "Teszt Runner");
});

test("PUT /api/shoes/:id módosítja a terméket", async () => {
  const response = await fetch(`${baseUrl}/api/shoes/${createdId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ price: 21990 })
  });
  const shoe = await response.json();
  assert.equal(response.status, 200);
  assert.equal(shoe.price, 21990);
});

test("DELETE /api/shoes/:id törli a terméket", async () => {
  const response = await fetch(`${baseUrl}/api/shoes/${createdId}`, { method: "DELETE" });
  assert.equal(response.status, 200);
  const getResponse = await fetch(`${baseUrl}/api/shoes/${createdId}`);
  assert.equal(getResponse.status, 404);
});

test("hibás POST 400 választ ad", async () => {
  const response = await fetch(`${baseUrl}/api/shoes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "Hiányos termék" })
  });
  assert.equal(response.status, 400);
});

test("GET /about egy saját oldalt ad vissza", async () => {
  const response = await fetch(`${baseUrl}/about`);
  const text = await response.text();
  assert.equal(response.status, 200);
  assert.match(text, /StrideLab/i);
});

test("az akciós ár nem lehet magasabb az eredeti árnál", async () => {
  const response = await fetch(`${baseUrl}/api/shoes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Hibás akció",
      brand: "StrideLab",
      price: 39990,
      oldPrice: 29990
    })
  });
  assert.equal(response.status, 400);
});
