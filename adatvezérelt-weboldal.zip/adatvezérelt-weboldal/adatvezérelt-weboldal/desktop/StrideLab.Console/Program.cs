using System.Net.Http.Json;
using System.Text.Json;

const string apiUrl = "http://localhost:3000/api/shoes";
using var client = new HttpClient();

try
{
    var shoes = await client.GetFromJsonAsync<List<Shoe>>(apiUrl) ?? [];
    Console.WriteLine("StrideLab termékkatalógus");
    Console.WriteLine("--------------------------");
    foreach (var shoe in shoes)
    {
        Console.WriteLine($"{shoe.Name} | {shoe.Brand} | {shoe.Price:N0} Ft");
    }
}
catch (HttpRequestException)
{
    Console.WriteLine("A REST backend nem érhető el. Indítsd el: npm start");
}

public sealed record Shoe(
    JsonElement Id,
    string Name,
    string Brand,
    string Category,
    string Gender,
    string Description,
    decimal Price,
    decimal? OldPrice,
    string Image);
