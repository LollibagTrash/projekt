using System.Net.Http.Json;
using System.Text.Json;

namespace StrideLab.Desktop;

public sealed class ShoeApiClient
{
    private readonly HttpClient client = new() { BaseAddress = new Uri("http://localhost:3000/api/") };

    public async Task<List<Shoe>> GetShoesAsync(CancellationToken cancellationToken = default)
    {
        return await client.GetFromJsonAsync<List<Shoe>>("shoes", cancellationToken) ?? [];
    }

    public async Task<Shoe> CreateShoeAsync(ShoeInput input, CancellationToken cancellationToken = default)
    {
        using var response = await client.PostAsJsonAsync("shoes", input, cancellationToken);
        return await ReadResponseAsync<Shoe>(response, cancellationToken);
    }

    public async Task<Shoe> UpdateShoeAsync(JsonElement id, ShoeInput input, CancellationToken cancellationToken = default)
    {
        using var response = await client.PutAsJsonAsync($"shoes/{GetIdValue(id)}", input, cancellationToken);
        return await ReadResponseAsync<Shoe>(response, cancellationToken);
    }

    public async Task DeleteShoeAsync(JsonElement id, CancellationToken cancellationToken = default)
    {
        using var response = await client.DeleteAsync($"shoes/{GetIdValue(id)}", cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(await response.Content.ReadAsStringAsync(cancellationToken));
        }
    }

    private static async Task<T> ReadResponseAsync<T>(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (!response.IsSuccessStatusCode)
        {
            var message = await response.Content.ReadAsStringAsync(cancellationToken);
            throw new InvalidOperationException(message);
        }

        return (await response.Content.ReadFromJsonAsync<T>(cancellationToken: cancellationToken))
            ?? throw new InvalidOperationException("A szerver üres választ adott.");
    }

    private static string GetIdValue(JsonElement id) => id.ValueKind switch
    {
        JsonValueKind.String => Uri.EscapeDataString(id.GetString() ?? string.Empty),
        JsonValueKind.Number => id.ToString(),
        _ => throw new InvalidOperationException("Érvénytelen termékazonosító.")
    };
}

public sealed record ShoeInput(
    string Name,
    string Brand,
    string Category,
    string Gender,
    string Description,
    decimal Price,
    decimal? OldPrice,
    string Image);
