namespace StrideLab.Desktop;

public sealed class ProductDialog : Form
{
    private readonly TextBox nameBox = CreateTextBox();
    private readonly TextBox brandBox = CreateTextBox();
    private readonly TextBox categoryBox = CreateTextBox();
    private readonly TextBox genderBox = CreateTextBox();
    private readonly TextBox descriptionBox = CreateTextBox();
    private readonly NumericUpDown priceBox = CreatePriceBox();
    private readonly NumericUpDown oldPriceBox = CreatePriceBox();
    private readonly CheckBox saleBox = new() { Text = "Akciós ár megadása", AutoSize = true };
    private readonly TextBox imageBox = CreateTextBox();
    private readonly Label errorLabel = new() { AutoSize = true, ForeColor = Color.FromArgb(255, 112, 112) };
    private readonly Button saveButton = new() { Text = "MENTÉS", DialogResult = DialogResult.None, AutoSize = true };

    public ShoeInput? Result { get; private set; }

    public ProductDialog(Shoe? shoe = null)
    {
        Text = shoe is null ? "Új termék" : "Termék szerkesztése";
        Width = 520;
        Height = 610;
        MinimumSize = new Size(520, 610);
        BackColor = CatalogForm.CanvasColor;
        ForeColor = CatalogForm.MainTextColor;
        StartPosition = FormStartPosition.CenterParent;

        var fields = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 9,
            Padding = new Padding(24),
            BackColor = CatalogForm.SurfaceColor
        };
        fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (var index = 0; index < fields.RowCount; index++) fields.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        fields.RowStyles[4] = new RowStyle(SizeType.Absolute, 85);
        fields.RowStyles[8] = new RowStyle(SizeType.Absolute, 60);
        descriptionBox.Multiline = true;
        descriptionBox.ScrollBars = ScrollBars.Vertical;

        AddField(fields, 0, "Név *", nameBox);
        AddField(fields, 1, "Márka *", brandBox);
        AddField(fields, 2, "Kategória", categoryBox);
        AddField(fields, 3, "Célcsoport", genderBox);
        AddField(fields, 4, "Leírás", descriptionBox);
        AddField(fields, 5, "Ár (Ft) *", priceBox);
        AddField(fields, 7, "Kép URL", imageBox);

        var salePanel = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        salePanel.Controls.Add(oldPriceBox);
        salePanel.Controls.Add(saleBox);
        oldPriceBox.Width = 145;
        saleBox.Padding = new Padding(8, 5, 0, 0);
        fields.Controls.Add(new Label { Text = "Eredeti ár", AutoSize = true, Anchor = AnchorStyles.Left, ForeColor = CatalogForm.MutedTextColor, Padding = new Padding(0, 5, 0, 0) }, 0, 6);
        fields.Controls.Add(salePanel, 1, 6);
        fields.Controls.Add(errorLabel, 1, 8);

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 60,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(24, 10, 24, 10),
            BackColor = CatalogForm.SurfaceColor
        };
        var cancelButton = new Button { Text = "MÉGSEM", DialogResult = DialogResult.Cancel, AutoSize = true };
        buttons.Controls.Add(saveButton);
        buttons.Controls.Add(cancelButton);
        fields.Controls.Add(buttons, 0, 8);

        Controls.Add(fields);
        AcceptButton = saveButton;
        CancelButton = cancelButton;
        saveButton.Click += (_, _) => SaveProduct();
        saleBox.CheckedChanged += (_, _) => oldPriceBox.Enabled = saleBox.Checked;
        oldPriceBox.Enabled = false;

        if (shoe is not null) FillFromShoe(shoe);
        ApplyTheme(fields);
    }

    private static TextBox CreateTextBox() => new() { Dock = DockStyle.Fill, BackColor = CatalogForm.RaisedSurfaceColor, ForeColor = CatalogForm.MainTextColor, BorderStyle = BorderStyle.FixedSingle };

    private static NumericUpDown CreatePriceBox() => new() { Dock = DockStyle.Fill, Maximum = 10000000, ThousandsSeparator = true, DecimalPlaces = 0, BackColor = CatalogForm.RaisedSurfaceColor, ForeColor = CatalogForm.MainTextColor };

    private static void AddField(TableLayoutPanel panel, int row, string caption, Control control)
    {
        panel.Controls.Add(new Label { Text = caption, AutoSize = true, Anchor = AnchorStyles.Left, ForeColor = CatalogForm.MutedTextColor, Padding = new Padding(0, 5, 0, 0) }, 0, row);
        panel.Controls.Add(control, 1, row);
    }

    private static void ApplyTheme(Control control)
    {
        foreach (Control child in control.Controls)
        {
            if (child is Button button)
            {
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderSize = 0;
                button.BackColor = button.Text == "MENTÉS" ? CatalogForm.PrimaryColor : CatalogForm.RaisedSurfaceColor;
                button.ForeColor = button.Text == "MENTÉS" ? CatalogForm.CanvasColor : CatalogForm.MainTextColor;
                button.Padding = new Padding(12, 6, 12, 6);
            }
            if (child.HasChildren) ApplyTheme(child);
        }
    }

    private void FillFromShoe(Shoe shoe)
    {
        nameBox.Text = shoe.Name;
        brandBox.Text = shoe.Brand;
        categoryBox.Text = shoe.Category;
        genderBox.Text = shoe.Gender;
        descriptionBox.Text = shoe.Description;
        priceBox.Value = shoe.Price;
        imageBox.Text = shoe.Image;
        if (shoe.OldPrice.HasValue)
        {
            saleBox.Checked = true;
            oldPriceBox.Value = shoe.OldPrice.Value;
        }
    }

    private void SaveProduct()
    {
        if (string.IsNullOrWhiteSpace(nameBox.Text) || string.IsNullOrWhiteSpace(brandBox.Text))
        {
            errorLabel.Text = "A név és a márka kötelező.";
            return;
        }
        if (priceBox.Value <= 0)
        {
            errorLabel.Text = "Az árnak pozitívnak kell lennie.";
            return;
        }
        if (saleBox.Checked && oldPriceBox.Value <= priceBox.Value)
        {
            errorLabel.Text = "Az eredeti ár legyen magasabb az akciós árnál.";
            return;
        }

        Result = new ShoeInput(
            nameBox.Text.Trim(),
            brandBox.Text.Trim(),
            categoryBox.Text.Trim(),
            genderBox.Text.Trim(),
            descriptionBox.Text.Trim(),
            priceBox.Value,
            saleBox.Checked ? oldPriceBox.Value : null,
            imageBox.Text.Trim());
        DialogResult = DialogResult.OK;
    }
}
