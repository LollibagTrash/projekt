using System.Net.Http.Json;
using System.Text.Json;

namespace StrideLab.Desktop;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new CatalogForm());
    }
}

public sealed class CatalogForm : Form
{
    internal static readonly Color Canvas = Color.FromArgb(14, 20, 28);
    internal static readonly Color Surface = Color.FromArgb(22, 31, 42);
    internal static readonly Color SurfaceRaised = Color.FromArgb(29, 40, 53);
    internal static readonly Color Line = Color.FromArgb(51, 65, 81);
    internal static readonly Color Primary = Color.FromArgb(191, 255, 88);
    internal static readonly Color TextMain = Color.FromArgb(241, 245, 249);
    internal static readonly Color TextMuted = Color.FromArgb(148, 163, 184);
    internal static Color CanvasColor => Canvas;
    internal static Color SurfaceColor => Surface;
    internal static Color RaisedSurfaceColor => SurfaceRaised;
    internal static Color PrimaryColor => Primary;
    internal static Color MainTextColor => TextMain;
    internal static Color MutedTextColor => TextMuted;

    private readonly ListView products = new()
    {
        Dock = DockStyle.Fill,
        View = View.Details,
        FullRowSelect = true,
        GridLines = false,
        HideSelection = false,
        MultiSelect = false,
        HeaderStyle = ColumnHeaderStyle.Nonclickable,
        Font = new Font("Segoe UI", 10F),
        BackColor = Surface,
        ForeColor = TextMain,
        BorderStyle = BorderStyle.None
    };
    private readonly TextBox searchBox = new()
    {
        Width = 250,
        PlaceholderText = "Keresés név vagy márka szerint..."
    };
    private readonly Button refreshButton = new()
    {
        Text = "  FRISSÍTÉS  ",
        AutoSize = true,
        Padding = new Padding(10, 7, 10, 7),
        FlatStyle = FlatStyle.Flat,
        BackColor = Primary,
        ForeColor = Color.FromArgb(14, 20, 28),
        Font = new Font("Segoe UI Semibold", 9F)
    };
    private readonly Label resultCount = new()
    {
        AutoSize = true,
        Text = "0 TERMÉK",
        ForeColor = TextMuted,
        Padding = new Padding(12, 8, 0, 0)
    };
    private readonly ComboBox sortBox = new()
    {
        Width = 150,
        DropDownStyle = ComboBoxStyle.DropDownList,
        FlatStyle = FlatStyle.Flat,
        BackColor = SurfaceRaised,
        ForeColor = TextMain
    };
    private readonly ShoeApiClient apiClient = new();
    private readonly Button addButton = CreateActionButton("+  ÚJ TERMÉK");
    private readonly Button editButton = CreateActionButton("SZERKESZTÉS");
    private readonly Button deleteButton = CreateActionButton("TÖRLÉS");
    private readonly PictureBox productImage = new()
    {
        Dock = DockStyle.Top,
        Height = 190,
        SizeMode = PictureBoxSizeMode.Zoom,
        BackColor = SurfaceRaised
    };
    private readonly Label catalogMetric = CreateMetricLabel();
    private readonly Label saleMetric = CreateMetricLabel();
    private readonly Label averageMetric = CreateMetricLabel();
    private readonly Label detailsTitle = new()
    {
        Dock = DockStyle.Top,
        AutoSize = false,
        Height = 36,
        Font = new Font("Segoe UI Semibold", 19F),
        ForeColor = Primary
    };
    private readonly Label detailsText = new()
    {
        Dock = DockStyle.Fill,
        AutoEllipsis = false,
        Font = new Font("Segoe UI", 10F),
        ForeColor = TextMain,
        Padding = new Padding(0, 8, 18, 0)
    };
    private List<Shoe> allShoes = [];
    private readonly Label status = new()
    {
        Dock = DockStyle.Bottom,
        Height = 28,
        Text = "  KAPCSOLAT: API /api/shoes  |  BETÖLTÉS...",
        TextAlign = ContentAlignment.MiddleLeft,
        Padding = new Padding(8, 0, 0, 0),
        BackColor = Surface,
        ForeColor = TextMuted
    };

    private static Label CreateMetricLabel() => new()
    {
        AutoSize = true,
        Font = new Font("Segoe UI Semibold", 17F),
        ForeColor = Primary,
        Margin = new Padding(0, 0, 34, 0)
    };

    private static Button CreateActionButton(string text) => new()
    {
        Text = text,
        AutoSize = true,
        FlatStyle = FlatStyle.Flat,
        BackColor = SurfaceRaised,
        ForeColor = TextMain,
        Padding = new Padding(10, 7, 10, 7),
        Font = new Font("Segoe UI Semibold", 9F)
    };

    public CatalogForm()
    {
        Text = "StrideLab katalógus";
        Width = 1180;
        Height = 760;
        MinimumSize = new Size(900, 600);
        BackColor = Canvas;
        ForeColor = TextMain;

        sortBox.Items.AddRange(["Alapértelmezett", "Ár: növekvő", "Ár: csökkenő", "Név szerint"]);
        sortBox.SelectedIndex = 0;

        products.Columns.Add("MODELL", 250);
        products.Columns.Add("MARKA", 140);
        products.Columns.Add("KATEGORIA", 160);
        products.Columns.Add("EREDETI ÁR", 135, HorizontalAlignment.Right);
        products.Columns.Add("AKCIÓS ÁR", 135, HorizontalAlignment.Right);
        products.Columns.Add(" ", 120);
        products.OwnerDraw = true;
        products.DrawColumnHeader += DrawColumnHeader;
        products.DrawItem += DrawProductItem;
        products.DrawSubItem += DrawProductSubItem;
        products.SelectedIndexChanged += (_, _) => ShowSelectedShoe();
        sortBox.SelectedIndexChanged += (_, _) => RenderProducts();
        refreshButton.FlatAppearance.BorderSize = 0;
        foreach (var button in new[] { addButton, editButton, deleteButton })
        {
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = Line;
        }
        addButton.Click += async (_, _) => await AddProductAsync();
        editButton.Click += async (_, _) => await EditProductAsync();
        deleteButton.Click += async (_, _) => await DeleteProductAsync();
        SetCrudButtonsEnabled(false);

        var title = new Label
        {
            Text = "StrideLab katalógus",
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 25F),
            ForeColor = TextMain,
            Margin = new Padding(0, 0, 0, 4)
        };
        var subtitle = new Label
        {
            Text = "RUNNING INTELLIGENCE  /  LIVE CATALOG",
            AutoSize = true,
            ForeColor = Primary,
            Font = new Font("Segoe UI Semibold", 9F),
            Margin = new Padding(0, 0, 0, 16)
        };
        var header = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 122,
            Padding = new Padding(30, 20, 30, 8),
            BackColor = Canvas,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false
        };
        header.Controls.Add(title);
        header.Controls.Add(subtitle);

        var metrics = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 70,
            Padding = new Padding(30, 10, 30, 10),
            BackColor = Canvas,
            WrapContents = false
        };
        metrics.Controls.Add(CreateMetricBlock("KATALÓGUS", catalogMetric));
        metrics.Controls.Add(CreateMetricBlock("AKCIÓS MODELLEK", saleMetric));
        metrics.Controls.Add(CreateMetricBlock("ÁTLAGOS ÁR", averageMetric));

        var toolbar = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 68,
            Padding = new Padding(30, 14, 30, 10),
            BackColor = Surface,
            ColumnCount = 2,
            RowCount = 1
        };
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
        toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
        var filterControls = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, Margin = new Padding(0), BackColor = Surface };
        filterControls.Controls.Add(searchBox);
        filterControls.Controls.Add(sortBox);
        filterControls.Controls.Add(refreshButton);
        var actionControls = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, FlowDirection = FlowDirection.RightToLeft, Margin = new Padding(0), BackColor = Surface };
        actionControls.Controls.Add(deleteButton);
        actionControls.Controls.Add(editButton);
        actionControls.Controls.Add(addButton);
        actionControls.Controls.Add(resultCount);
        toolbar.Controls.Add(filterControls, 0, 0);
        toolbar.Controls.Add(actionControls, 1, 0);
        searchBox.BackColor = SurfaceRaised;
        searchBox.ForeColor = TextMain;
        searchBox.BorderStyle = BorderStyle.FixedSingle;
        searchBox.TextChanged += (_, _) => RenderProducts();
        refreshButton.Click += async (_, _) => await LoadProducts();

        var detailsPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = SurfaceRaised,
            Padding = new Padding(22)
        };
        detailsPanel.Controls.Add(detailsText);
        detailsPanel.Controls.Add(productImage);
        detailsPanel.Controls.Add(detailsTitle);

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            SplitterDistance = 720,
            IsSplitterFixed = false,
            BackColor = Canvas,
            Padding = new Padding(30, 18, 30, 22)
        };
        split.Panel1.Controls.Add(products);
        split.Panel2.Controls.Add(detailsPanel);

        Controls.Add(split);
        Controls.Add(toolbar);
        Controls.Add(metrics);
        Controls.Add(header);
        Controls.Add(status);
        Load += async (_, _) => await LoadProducts();
    }

    private static Panel CreateMetricBlock(string caption, Label value)
    {
        var panel = new Panel
        {
            Width = 220,
            Height = 54,
            BackColor = Surface
        };
        var label = new Label
        {
            Text = caption,
            AutoSize = true,
            Font = new Font("Segoe UI", 8F),
            ForeColor = TextMuted,
            Location = new Point(12, 7)
        };
        value.Location = new Point(10, 22);
        panel.Controls.Add(value);
        panel.Controls.Add(label);
        return panel;
    }

    private async Task LoadProducts()
    {
        try
        {
            status.Text = "  KAPCSOLAT: API /api/shoes  |  BETÖLTÉS...";
            allShoes = await apiClient.GetShoesAsync();
            RenderProducts();
            status.Text = $"Betöltve: {allShoes.Count} termék | Utolsó frissítés: {DateTime.Now:HH:mm}";
        }
        catch (HttpRequestException)
        {
            status.Text = "A REST backend nem érhető el. Indítsd el: npm start";
        }
        catch (Exception error)
        {
            status.Text = $"Betöltési hiba: {error.Message}";
        }
    }

    private async Task AddProductAsync()
    {
        using var dialog = new ProductDialog();
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Result is null) return;
        try
        {
            await apiClient.CreateShoeAsync(dialog.Result);
            await LoadProducts();
            status.Text = "  UJ TERMÉK SIKERESEN LÉTREHOZVA";
        }
        catch (Exception error)
        {
            status.Text = $"  MENTÉSI HIBA: {GetErrorMessage(error)}";
        }
    }

    private async Task EditProductAsync()
    {
        var shoe = GetSelectedShoe();
        if (shoe is null) return;
        using var dialog = new ProductDialog(shoe);
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Result is null) return;
        try
        {
            await apiClient.UpdateShoeAsync(shoe.Id, dialog.Result);
            await LoadProducts();
            status.Text = "  TERMÉK SIKERESEN FRISSÍTVE";
        }
        catch (Exception error)
        {
            status.Text = $"  MÓDOSÍTÁSI HIBA: {GetErrorMessage(error)}";
        }
    }

    private async Task DeleteProductAsync()
    {
        var shoe = GetSelectedShoe();
        if (shoe is null) return;
        if (MessageBox.Show($"Biztosan törlöd a(z) {shoe.Name} terméket?", "Törlés megerősítése", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        try
        {
            await apiClient.DeleteShoeAsync(shoe.Id);
            await LoadProducts();
            status.Text = "  TERMÉK SIKERESEN TÖRÖLVE";
        }
        catch (Exception error)
        {
            status.Text = $"  TÖRLÉSI HIBA: {GetErrorMessage(error)}";
        }
    }

    private Shoe? GetSelectedShoe() => products.SelectedItems.Count == 0 ? null : (Shoe)products.SelectedItems[0].Tag!;

    private async Task LoadProductImageAsync(string imageUrl)
    {
        productImage.Image = null;
        if (string.IsNullOrWhiteSpace(imageUrl)) return;
        try
        {
            using var client = new HttpClient();
            using var stream = await client.GetStreamAsync(imageUrl);
            using var downloadedImage = Image.FromStream(stream);
            productImage.Image = new Bitmap(downloadedImage);
        }
        catch
        {
            status.Text = "  A TERMÉKKÉP NEM ÉRHETŐ EL, A KATALÓGUS TOVÁBBRA IS HASZNÁLHATÓ";
        }
    }

    private static string GetErrorMessage(Exception error)
    {
        return error is InvalidOperationException && error.Message.Contains("error", StringComparison.OrdinalIgnoreCase)
            ? "A szerver elutasította a kérést. Ellenőrizd az adatokat."
            : error.Message;
    }

    private void RenderProducts()
    {
        var query = searchBox.Text.Trim();
        var filteredShoes = allShoes
            .Where(shoe => string.IsNullOrWhiteSpace(query)
                || shoe.Name.Contains(query, StringComparison.CurrentCultureIgnoreCase)
                || shoe.Brand.Contains(query, StringComparison.CurrentCultureIgnoreCase))
            .ToList();

        if (sortBox.SelectedIndex == 1) filteredShoes.Sort((left, right) => left.Price.CompareTo(right.Price));
        if (sortBox.SelectedIndex == 2) filteredShoes.Sort((left, right) => right.Price.CompareTo(left.Price));
        if (sortBox.SelectedIndex == 3) filteredShoes.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.CurrentCultureIgnoreCase));

        catalogMetric.Text = allShoes.Count.ToString();
        saleMetric.Text = allShoes.Count(shoe => shoe.OldPrice.HasValue).ToString();
        averageMetric.Text = allShoes.Count == 0 ? "0 Ft" : $"{allShoes.Average(shoe => shoe.Price):N0} Ft";

        products.BeginUpdate();
        products.Items.Clear();
        foreach (var shoe in filteredShoes)
        {
            var row = new ListViewItem(shoe.Name);
            row.SubItems.Add(shoe.Brand);
            row.SubItems.Add(shoe.Category);
            row.SubItems.Add(shoe.OldPrice.HasValue ? $"{shoe.OldPrice.Value:N0} Ft" : "Nincs akció");
            row.SubItems.Add($"{shoe.Price:N0} Ft");
            row.SubItems.Add(string.Empty);
            row.Tag = shoe;
            products.Items.Add(row);
        }
        products.EndUpdate();
        if (products.Items.Count > 0)
        {
            products.Items[0].Selected = true;
            products.Select();
        }
        resultCount.Text = $"{filteredShoes.Count} TALÁLAT";
        ShowSelectedShoe();
    }

    private void ShowSelectedShoe()
    {
        if (products.SelectedItems.Count == 0)
        {
            detailsTitle.Text = "Válasszon egy terméket";
            detailsText.Text = "A részletek itt jelennek meg a katalógus egy elemének kiválasztása után.";
            productImage.Image = null;
            SetCrudButtonsEnabled(false);
            return;
        }

        var shoe = (Shoe)products.SelectedItems[0].Tag!;
        SetCrudButtonsEnabled(true);
        detailsTitle.Text = shoe.Name;
        var priceText = shoe.OldPrice.HasValue
            ? $"Eredeti ár: {shoe.OldPrice.Value:N0} Ft\nAkciós ár: {shoe.Price:N0} Ft\nKedvezmény: {CalculateDiscount(shoe):0}%"
            : $"Ár: {shoe.Price:N0} Ft\nAkciós státusz: Nincs akció";
        detailsText.Text = $"Márka: {shoe.Brand}\nKategória: {shoe.Category}\nCélcsoport: {shoe.Gender}\n\n{priceText}\n\n{shoe.Description}";
        _ = LoadProductImageAsync(shoe.Image);
    }

    private static decimal CalculateDiscount(Shoe shoe) => shoe.OldPrice.HasValue
        ? (shoe.OldPrice.Value - shoe.Price) / shoe.OldPrice.Value * 100
        : 0;

    private void SetCrudButtonsEnabled(bool enabled)
    {
        editButton.Enabled = enabled;
        deleteButton.Enabled = enabled;
    }

    private void DrawColumnHeader(object? sender, DrawListViewColumnHeaderEventArgs eventArgs)
    {
        if (eventArgs.Header is null) return;
        using var background = new SolidBrush(SurfaceRaised);
        using var text = new SolidBrush(TextMuted);
        eventArgs.Graphics.FillRectangle(background, eventArgs.Bounds);
        eventArgs.Graphics.DrawString(eventArgs.Header.Text, new Font("Segoe UI Semibold", 8.5F), text, eventArgs.Bounds.Left + 8, eventArgs.Bounds.Top + 7);
    }

    private void DrawProductItem(object? sender, DrawListViewItemEventArgs eventArgs)
    {
        eventArgs.DrawDefault = false;
    }

    private void DrawProductSubItem(object? sender, DrawListViewSubItemEventArgs eventArgs)
    {
        if (eventArgs.Item is null || eventArgs.SubItem is null) return;
        var selected = eventArgs.Item.Selected;
        var backgroundColor = selected ? Color.FromArgb(54, 75, 58) : Surface;
        var foregroundColor = eventArgs.ColumnIndex == 4 && eventArgs.Item.Tag is Shoe shoe && shoe.OldPrice.HasValue
            ? Primary
            : TextMain;
        using var background = new SolidBrush(backgroundColor);
        using var foreground = new SolidBrush(foregroundColor);
        eventArgs.Graphics.FillRectangle(background, eventArgs.Bounds);
        var format = new StringFormat { LineAlignment = StringAlignment.Center };
        eventArgs.Graphics.DrawString(eventArgs.SubItem.Text, products.Font!, foreground, eventArgs.Bounds.Left + 8, eventArgs.Bounds.Top + eventArgs.Bounds.Height / 2, format);
        if (eventArgs.ColumnIndex == 3 && eventArgs.Item.Tag is Shoe discountedShoe && discountedShoe.OldPrice.HasValue)
        {
            using var strikePen = new Pen(TextMuted, 1.5F);
            var textWidth = eventArgs.Graphics.MeasureString(eventArgs.SubItem.Text, products.Font!).Width;
            var y = eventArgs.Bounds.Top + eventArgs.Bounds.Height / 2;
            eventArgs.Graphics.DrawLine(strikePen, eventArgs.Bounds.Left + 8, y, eventArgs.Bounds.Left + 8 + textWidth, y);
        }
    }
}

public sealed record Shoe(
    JsonElement Id,
    string Name,
    string Brand,
    string Category,
    string Gender,
    string Description,
    decimal Price,
    decimal? OldPrice,
    string Image);
