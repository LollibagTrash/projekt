# StrideLab desktop release

This folder contains the reproducible desktop packaging files required for the submission package.

## Prerequisites

- .NET 10 SDK
- Windows
- Node.js 18 or newer for the REST backend
- Inno Setup 6 for compiling the `.exe` installer

## Build

From the repository root, run:

```powershell
.\installer\build-release.ps1
```

The script publishes both desktop clients into `installer/release` and creates the immediately distributable `installer/StrideLab-Desktop-Release.zip`. When `iscc.exe` is available on `PATH`, it also creates `installer/output/StrideLab-Setup-1.0.0.exe`.

If Inno Setup is not on `PATH`, install it and run:

```powershell
iscc.exe installer/StrideLab.iss
```

The installed clients still require the backend to be started separately with `npm start` from the project root.
