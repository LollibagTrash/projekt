$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$release = Join-Path $PSScriptRoot "release"
$consoleOutput = Join-Path $release "StrideLab.Console"
$desktopOutput = Join-Path $release "StrideLab.Desktop"

if (Test-Path $release) {
    Remove-Item $release -Recurse -Force
}

New-Item -ItemType Directory -Path $consoleOutput -Force | Out-Null
New-Item -ItemType Directory -Path $desktopOutput -Force | Out-Null

Push-Location $root
try {
    dotnet publish "desktop/StrideLab.Console/StrideLab.Console.csproj" -c Release --self-contained false -o $consoleOutput
    dotnet publish "desktop/StrideLab.Desktop/StrideLab.Desktop.csproj" -c Release --self-contained false -o $desktopOutput
}
finally {
    Pop-Location
}

Compress-Archive -Path (Join-Path $release "*") -DestinationPath (Join-Path $PSScriptRoot "StrideLab-Desktop-Release.zip") -Force

$innoCompiler = Get-Command iscc.exe -ErrorAction SilentlyContinue
if ($null -eq $innoCompiler) {
    $localInnoPath = Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe"
    if (Test-Path $localInnoPath) {
        $innoCompiler = [PSCustomObject]@{ Source = $localInnoPath }
    }
}

if ($null -ne $innoCompiler) {
    & $innoCompiler.Source (Join-Path $PSScriptRoot "StrideLab.iss")
    Write-Host "Installer created in installer/output."
}
else {
    Write-Warning "Inno Setup was not found. Publish folders were created, but the .exe installer was not compiled."
    Write-Host "Install Inno Setup, then run: iscc.exe installer/StrideLab.iss"
}

Write-Host "Release files created in installer/release."
