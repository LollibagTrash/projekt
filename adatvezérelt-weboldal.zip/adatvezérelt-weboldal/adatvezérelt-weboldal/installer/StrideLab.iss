#define AppName "StrideLab"
#define AppVersion "1.0.0"
#define AppPublisher "StrideLab Team"
#define RootDir SourcePath

[Setup]
AppId={{A8D4B8B7-9E17-4DA7-9FD4-202609210001}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\StrideLab
DefaultGroupName=StrideLab
OutputDir={#RootDir}\output
OutputBaseFilename=StrideLab-Setup-{#AppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Files]
Source: "{#RootDir}\release\StrideLab.Desktop\*"; DestDir: "{app}\Desktop"; Flags: recursesubdirs ignoreversion
Source: "{#RootDir}\release\StrideLab.Console\*"; DestDir: "{app}\Console"; Flags: recursesubdirs ignoreversion
Source: "{#RootDir}\..\server.js"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\db.json"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\package.json"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\index.html"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\about.html"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\app.js"; DestDir: "{app}\Backend"; Flags: ignoreversion
Source: "{#RootDir}\..\style.css"; DestDir: "{app}\Backend"; Flags: ignoreversion

[Icons]
Name: "{group}\StrideLab Desktop"; Filename: "{app}\Desktop\StrideLab.Desktop.exe"; WorkingDir: "{app}\Desktop"
Name: "{group}\StrideLab Console"; Filename: "{app}\Console\StrideLab.Console.exe"; WorkingDir: "{app}\Console"
Name: "{commondesktop}\StrideLab Desktop"; Filename: "{app}\Desktop\StrideLab.Desktop.exe"; WorkingDir: "{app}\Desktop"

[Dirs]
Name: "{app}\Backend"

[Run]
Filename: "{app}\Desktop\StrideLab.Desktop.exe"; Description: "Start StrideLab Desktop"; Flags: nowait postinstall skipifsilent
