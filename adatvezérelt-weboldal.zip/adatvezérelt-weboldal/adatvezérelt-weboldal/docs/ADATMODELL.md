# StrideLab adatmodell

A projekt egy `shoes` erőforrást kezel JSON-alapú perzisztens adattárolással. A fájl egyben adatbázis-exportként (dump) is használható.

## Entitás: shoes

| Mező | Típus | Kötelező | Leírás |
|---|---|---:|---|
| `id` | string vagy integer | igen | Egyedi termékazonosító |
| `name` | string | igen | Modell neve |
| `brand` | string | igen | Gyártó vagy márka |
| `category` | string | igen | Termékkategória |
| `gender` | string | igen | Célcsoport |
| `description` | string | igen | Rövid termékleírás |
| `price` | number | igen | Aktuális ár forintban |
| `oldPrice` | number vagy null | nem | Korábbi ár akció esetén |
| `image` | string | igen | Termékkép URL-je |

## Kapcsolatok

A jelenlegi katalógusban a `shoes` önálló entitás. A kosár böngészőnként a `localStorage`-ban tárolódik, mert a bemutató webáruház nem kezel felhasználói fiókokat.

```mermaid
erDiagram
    SHOES {
        string id PK
        string name
        string brand
        string category
        string gender
        string description
        number price
        number oldPrice
        string image
    }
```
