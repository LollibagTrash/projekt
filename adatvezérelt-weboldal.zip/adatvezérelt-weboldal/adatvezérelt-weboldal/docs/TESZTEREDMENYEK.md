# Teszteredmények

## Automatizált tesztek futtatása

```bash
npm test
```

## Utolsó eredmény

- Tesztfájl: `tests/api.test.js`
- Futtatási parancs: `npm test`
- Összes teszt: 7
- Sikeres: 7
- Sikertelen: 0
- Futtatási környezet: Node.js 18 vagy újabb, Windows 11

## Ellenőrzött esetek

1. `GET /api/shoes` terméklista visszaadása.
2. `POST /api/shoes` új termék létrehozása.
3. `PUT /api/shoes/:id` termék módosítása.
4. `DELETE /api/shoes/:id` termék törlése.
5. Hibás POST kérés elutasítása `400` státusszal.
6. Nem létező termék lekérése `404` státusszal.
7. Az eredeti árnál magasabb akciós ár elutasítása `400` státusszal.

## Manuális frontend ellenőrzőlista

- termékek betöltése API-ról és fallback adatból
- keresés modell, márka és kategória alapján
- márkaszűrés
- ár- és név szerinti rendezés
- akciós termékek szűrése
- részletező modal megnyitása és bezárása
- kosárba helyezés, törlés és végösszeg
- rendelési adatok validálása
- ajánlatkérő űrlap elküldése inline visszajelzéssel
- mobil elrendezés ellenőrzése

## Manuális tesztelési jegyzőkönyv

| Azonosító | Környezet | Lépés | Elvárt eredmény | Eredmény |
|---|---|---|---|---|
| M-01 | Chrome desktop | A főoldal megnyitása futó backend mellett | A termékek az API-ról betöltődnek | Megfelelt |
| M-02 | Chrome desktop | Keresés modell- és márkanévre | A lista csak a megfelelő termékeket mutatja | Megfelelt |
| M-03 | Chrome desktop | Termék részleteinek és kosárnak megnyitása | A részletező ablak és a kosár működik | Megfelelt |
| M-04 | Chrome mobil nézet, 390 px | A főoldal és a katalógus megnyitása | Nincs vízszintes kilógás, a vezérlők használhatók | Megfelelt |
| M-05 | Chrome desktop | Üres vagy hibás rendelési adatok elküldése | A kliens validációs üzenetet jelenít meg | Megfelelt |
| M-06 | Chrome desktop | Backend leállítása, majd oldalfrissítés | A fallback terméklista és tájékoztató üzenet megjelenik | Megfelelt |
| M-07 | WinForms desktop | Katalógus betöltése, keresés és rendezés | A C# kliens az API adatait megjeleníti | Megfelelt |

## Ismert korlátozás

A rendelés- és ajánlatkérő űrlap bemutató funkció: a kliens validálja az adatokat és visszajelzést ad, de a projekt nem kezel felhasználói fiókokat vagy rendelési adatbázist.
