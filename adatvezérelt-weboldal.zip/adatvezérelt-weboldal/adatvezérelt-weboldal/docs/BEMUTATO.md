# Vizsgabemutato vazlat

## Magyar bemutato

1. A StrideLab célja es a vasarloi problema.
2. A webes felulet bemutatasa desktop es mobil nezetben.
3. REST API es JSON adattarolas bemutatasa.
4. Kereses, szures, kosar es ajanlatkeres bemutatasa.
5. C# konzolos es WinForms kliens bemutatasa.
6. Tesztek futtatasa es eredmenyeinek ismertetese.
7. Forraskod, adatmodell es csapaton beluli munkamegosztas.

## Rovid angol osszefoglalo

> StrideLab is a fictional running shoe webshop. Users can browse products, search by name or brand, filter sale items, sort by price, open product details and add items to a local shopping cart. The web client communicates with a Node.js REST API. The API stores product data in a JSON database file and supports GET, POST, PUT and DELETE operations. The project also includes a C# console client and a Windows Forms desktop client. Automated tests verify the main API operations and invalid input handling.

## Csapat es munkamegosztas

- **Fabian Tamas** - adatbazis- es adatmodell-fejleszto: `db.json`, adatmodell, adatbazis-export es adat-elokeszites.
- **Kovacs Martin** - backend fejleszto es tesztelo: REST API, szerveroldali adatkezeles, validacio, automatizalt API-tesztek es tesztdokumentacio.
- **Rutai Annamaria** - frontend-, mobil- es desktopfejleszto: reszponziv webes frontend, mobil kliens, C# konzolos kliens es WinForms asztali kliens.

## Technikai feltetelek

- Node.js 18 vagy ujabb
- .NET 10 SDK a desktop kliensekhez
- bongeszo desktop vagy mobil nezettel
- a REST backend futtatasa a kliensek hasznalata elott

## Projektszervezesi eszkozok

- GitHub repository: forraskod-megosztas, verziozas es kiadasok.
- GitHub Issues: feladatok, hibak es fejlesztesi teendok nyilvantartasa.
- Pull request alapú ellenorzes: a modositasok atnezese es tesztelese beolvadas elott.
- A csapat a feladatokat adatbazis, backend es teszteles, valamint frontend, mobil es desktop kliens teruletekre osztotta.

## Beadasi ellenorzo lista

- Forraskod: a projekt gyokerkonyvtara.
- Webes kliens: `index.html`, `style.css`, `app.js`.
- REST backend: `server.js`.
- Adatmodell es adat-export: `docs/ADATMODELL.md`, `db.json`.
- Tesztkod es eredmenyek: `tests/api.test.js`, `docs/TESZTEREDMENYEK.md`.
- Desktop kiadas: az `installer` mappaban levo publish es Inno Setup fajlok.
- Bemutato anyag: ez a dokumentum.
